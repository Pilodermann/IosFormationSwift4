//
//  ViewController.swift
//  JeuDeLaCible
//
//  Created by neoloc on 22/05/2018.
//  Copyright © 2018 Romain. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var targetLabel: UILabel!
    @IBOutlet weak var roundLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var slider: UISlider!
    var roundValue: Int = 0
    var scoreValue: Int = 0
    var targetValue: Int = 0
    var sliderValue: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        slider.setThumbImage(UIImage(named: "SliderThumb-Normal"), for: UIControlState.normal)
        slider.setThumbImage(UIImage(named: "SliderThumb-Highlighted"), for: UIControlState.highlighted)
        let leftImage = UIImage(named: "SliderTrackRight")
        let rightImage = UIImage(named: "SliderTrackLeft")
        
        let insets = UIEdgeInsets(top: 0, left: 14, bottom: 0, right: 14)
        
        let rightImageResizable = rightImage?.resizableImage(withCapInsets: insets)
        
        let leftImageResizable = leftImage?.resizableImage(withCapInsets: insets)
        
        slider.setMaximumTrackImage( rightImageResizable, for: UIControlState.normal)
        slider.setMinimumTrackImage( leftImageResizable, for: UIControlState.highlighted)
        // Do any additional setup after loading the view, typically from a nib.
        resetValues()
    }

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showAlert()
    {
        let alert = UIAlertController(title: "Vraiment?", message: "Vous avez saisi \(slider.value)", preferredStyle: UIAlertControllerStyle.alert)
        
        let dif = abs(sliderValue - targetValue)
        var score:Int = 100 - abs(sliderValue - targetValue)
        
        var title: String
        if(sliderValue == targetValue){
            title = "Vous avez eu de la chance!"
            score += 50
            alert.message = "La valeur du slider est \(sliderValue)"+"\nVous marquez \(score) points"
        }else if(dif < 10) {
            title = "Dommage"
            alert.message = "La valeur du slider est \(sliderValue)"+"\nVous marquez seulement \(score) points"
        }else if(dif < 25) {
            title = "Vous le faites exprès?"
            score = score / 2
            alert.message = "La valeur du slider est \(sliderValue)"+"\nVous marquez seulement \(score) points"
        }else{
            title = "Aucun effort!"
            score = 0
            alert.message = "La valeur du slider est \(sliderValue)"+"\nVous ne marquez pas de points"
        }
        
        
        let action = UIAlertAction(title: title, style: UIAlertActionStyle.default, handler:  {(_) in self.initNewRound(score:score)})
        alert.addAction(action)
        
        present(alert, animated: true, completion: nil)
    
    }
    
    @IBAction func SliderValueChanged(_ sender: Any) {
        // print("\(slider.value)")
        sliderValue = lroundf(slider.value)
    }
    
    @IBAction func retryPressed(_ sender: Any) {
        resetValues()
    }
    
    private func initNewRound(score:Int){
        scoreValue += score
        scoreLabel.text = String(scoreValue)
        roundValue += 1
        roundLabel.text = String(roundValue)
        slider.value = 50
        sliderValue = lroundf(slider.value)
        targetValue = 1+Int(arc4random_uniform(100))
        targetLabel.text = String(targetValue)
    }
    
    private func resetValues(){
        slider.value = 50.0
        sliderValue = lroundf(slider.value)
        
        scoreValue = 0
        scoreLabel.text = String(scoreValue)
        targetValue = 1+Int(arc4random_uniform(100))
        targetLabel.text = String(targetValue)
        roundValue = 0
        roundLabel.text = String(roundValue)
    }
}
