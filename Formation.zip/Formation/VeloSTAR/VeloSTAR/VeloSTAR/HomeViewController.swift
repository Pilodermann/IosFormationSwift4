//
//  HomeViewController.swift
//  VeloSTAR
//
//  Created by neoloc on 22/05/2018.
//  Copyright © 2018 Romain. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import CoreData

class HomeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, MKMapViewDelegate, CLLocationManagerDelegate {

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var lcSelector: UISegmentedControl!
    var stationsArray : [Station]!
    var locationManager : CLLocationManager!
    var selectedStation : Station!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        
        mapView.delegate = self
        
        locationManager = CLLocationManager()
        locationManager.delegate = self;
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        locationManager.requestLocation()
        
        // Do any additional setup after loading the view.
        refreshStationList()
        fetchStations()
        centerMapOnLocation()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    public func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        print(locations)
        
        if(locations.count>0){
            for station in stationsArray{
                let stationPos = CLLocation(latitude: station.latitude, longitude: station.longitude)
                if let userlocation = locationManager.location{
                    station.distanceToStation = stationPos.distance(from: userlocation)
                }
            }
        }
        
        let sortedStationByDistance = stationsArray.sorted(by: {$0.distanceToStation < $1.distanceToStation})
        
        stationsArray = sortedStationByDistance
        
        tableView.reloadData()
        centerMapOnLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }
    
    /*
     * Reaction when selector selection changes
     */
    @IBAction func segmentControlValueChanged(_ sender: Any) {
        mapView.isHidden = 0 == lcSelector.selectedSegmentIndex;
        tableView.isHidden = 1 == lcSelector.selectedSegmentIndex;
    }
        
    /*
     * Return cell count
     */
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (self.stationsArray != nil) {
            return (self.stationsArray?.count)!
        }
        return 0
    }
    
    /**
     * Display cell content
     */
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "StationCellIdentifier", for: indexPath) as! BikeStationTableViewCell
        
        let station = self.stationsArray[indexPath.row]
        cell.stationLabel.text = station.name
        cell.availableSlotCount.text = station.nbAvailableSlots
        cell.availableBikeCount.text = station.nbAvailableBikes
        cell.setFavoriteIconVisible(isFavorite: station.favorite)
        
        if let distance = station.distanceToStation {
                var dist:String = String(format:"%.00f", distance)
                var unit = " m"
                if(distance > 1000){
                    dist = String(format: "%.01f", distance/1000)
                    unit = " km"
                }
                let distanceToStationText = "\(dist) \(unit)"
                cell.distanceToStation.text = distanceToStationText
            }else{
                cell.distanceToStation.text = ""
            }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectedStation = self.stationsArray[indexPath.row]
        performSegue(withIdentifier: "showDetailSegue", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetailSegue" {
            if let detailVC = segue.destination as? DetailViewController{
                detailVC.selectedStation = selectedStation
            }
        }
    }
    
    /*
     * Center the map on the user position
     */
    func centerMapOnLocation() {
        let rennesCenter = CLLocation(latitude: 48.1135, longitude: -1.6757)
        var currentLocation = rennesCenter
        if let location = locationManager.location{
            currentLocation = location
        }
        let zoneRadius: CLLocationDistance = 7000
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(currentLocation.coordinate, zoneRadius, zoneRadius)
        mapView.setRegion(coordinateRegion, animated: true)
    }
    
    /*
     * Put the station marker on the map
     */
    func addAnnotationsOnMap(){
        for station in stationsArray{
            let marker = StationAnnotation(coordinate: CLLocationCoordinate2D(latitude: station.latitude, longitude: station.longitude), stationName: station.name!, nbOfAvailableBikes: station.nbAvailableBikes!)
            mapView.addAnnotation(marker)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tableView.reloadData()
    }
    
    /*
     * Edit the apparence of the map annotation
     */
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if let stationAnnotation = annotation as? StationAnnotation{
            let view = MKAnnotationView(annotation: annotation, reuseIdentifier: stationAnnotation.stationName)
            let img = UIImage(named: "mapmarker_gray")
            view.image = img
            let label = UILabel(frame: CGRect(x: 6, y: 2, width: 20, height: 20))
            label.adjustsFontSizeToFitWidth = true
            label.textColor = UIColor.white
            label.text = stationAnnotation.nbOfAvailableBikes
            label.textAlignment = NSTextAlignment.center
            view.addSubview(label)
            return view
        }
        return MKAnnotationView(annotation: annotation, reuseIdentifier: nil)
    }
    
    /*
     * Update map annotation by removing them then adding them
     */
    func refreshMapAnnotations(){
        mapView.removeAnnotations(mapView.annotations)
        if(self.stationsArray != nil){
            addAnnotationsOnMap()
        }
    }
    // MARK: - API
    
    /*
     * Get station list from opendata
     * Create new stations in coredata
     * Delete old stations from coredata
     * Save new stations in coredata
     */
    func refreshStationList() {
        let urlString = "https://data.rennesmetropole.fr/api/records/1.0/search/?dataset=etat-des-stations-le-velo-star-en-temps-reel&rows=200&facet=nom&facet=etat&facet=nombreemplacementsactuels&facet=nombreemplacementsdisponibles&facet=nombrevelosdisponibles"
        
        guard let url = URL(string: urlString) else { return }
        
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if (error != nil) {
                print(error?.localizedDescription ?? "unknown error")
            }
            
            guard let data = data else { return }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                
                if let records = json["records"] as? NSArray {
                    DispatchQueue.main.async {
                        self.createStationEntitiesFrom(array: records)
                    }
                }
            } catch let error as NSError {
                print(error)
            }
            
            }.resume()
        
    }
    
    /*
     * Create core data entities from JSON text array
     */
    private func createStationEntitiesFrom(array: NSArray) {
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Station", in: context)
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Station")
        request.returnsObjectsAsFaults = false
        do {
            let stationList = try context.fetch(request) as! [Station]
        
            for station in array {
                if let stationDict = station as? NSDictionary {
                    if let stationFields = stationDict["fields"] as? NSDictionary {
                        print(stationFields)
                        
                        if let stationIdentifier = stationFields["idstation"] as? Int {
                            var stationTemp = stationAlreadyExists(identifier: String(stationIdentifier))
                            if(stationTemp == nil){
                                stationTemp = NSManagedObject(entity: entity!, insertInto: context) as? Station
                            }
                            let station:Station! = stationTemp
                            if let stationName = stationFields["nom"] as? String {
                                station.setValue(String(stationName), forKey: "name")
                            }
                            station.setValue(String(stationIdentifier), forKey: "identifier")
                            if let stationAvailableSlots = stationFields["nombreemplacementsdisponibles"] as? Int {
                                station.setValue(String(stationAvailableSlots), forKey: "nbAvailableSlots")
                            }
                            if let stationAvailableBikes = stationFields["nombrevelosdisponibles"] as? Int {
                                station.setValue(String(stationAvailableBikes), forKey: "nbAvailableBikes")
                            }
                            if let stationName = stationFields["etat"] as? String {
                                station.setValue(String(stationName), forKey: "state")
                            }
                            
                            if let stationCoordinates = stationFields["coordonnees"] as? NSArray {
                                if let latitude = stationCoordinates[0] as? Double {
                                    station.setValue(latitude, forKey: "latitude")
                                }
                                if let longitude = stationCoordinates[1] as? Double {
                                    station.setValue(longitude, forKey: "longitude")
                                }
                            }
                        }
                    }
                }
            
                do {
                    try context.save()
                } catch {
                    print("failed saving")
                }
            }
        } catch {
            print("error")
        }
        fetchStations()
        
    }
    
    private func stationAlreadyExists(identifier : String) -> Station?{
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Station")
        request.predicate = NSPredicate(format: "identifier = %@", identifier)
        do{
            let stationList = try context.fetch(request) as! [Station]
            if(stationList.count > 0){
                return stationList.first
            }
        }catch{
            print("Station existence not determined")
        }
        
        return nil;
    }
    
    /*
     * Get stations from Coredata and add them to the list
     */
    private func fetchStations() {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Station")
        request.returnsObjectsAsFaults = false
        do {
            let stationList = try context.fetch(request) as! [Station]
            self.stationsArray = stationList
        } catch {
            print("error")
            self.stationsArray = nil
        }
        
        self.tableView.reloadData()
        refreshMapAnnotations()
    }
        
        /*
         // MARK: - Navigation
         
         // In a storyboard-based application, you will often want to do a little preparation before navigation
         override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
         // Get the new view controller using segue.destinationViewController.
         // Pass the selected object to the new view controller.
         }
         */
        
}
    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        locationManager = CLLocationManager()
//        locationManager.delegate = locationManager.self as? CLLocationManagerDelegate
//        //deleteOldStations()
//        refreshDisplay()
//        refreshStationList()
//        fetchStations()
//        // Do any additional setup after loading the view.
//    }
//
//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        // Dispose of any resources that can be recreated.
//    }
//    
//    @IBAction func LCSelectorValueChanged(_ sender: Any) {
//        refreshDisplay()
//    }
//
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        if(self.stationArray == nil){
//            return 0
//        }
//        return self.stationArray.count
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "StationCellIdentifier", for: indexPath) as! BikeStationTableViewCell
//
//        let station = self.stationArray[indexPath.row]
//        cell.stationLabel.text = station.name
//        cell.availableSlotCount.text = station.nbAvailableSlots
//        cell.availableBikeCount.text = station.nbAvailableBikes
//
//        let stationPos = CLLocation(latitude: station.latitude, longitude: station.longitude)
//        if let userlocation = locationManager.location{
//            let distance = stationPos.distance(from: userlocation)/1000
//            cell.distanceToStation.text = String(distance)+" km"
//        }else{
//            cell.distanceToStation.text = "? km"
//        }
//
//        return cell;
//    }
//
//    private func refreshDisplay(){
//        mapView.isHidden = 0 == lcSelector.selectedSegmentIndex;
//        tableView.isHidden = 1 == lcSelector.selectedSegmentIndex;
//    }
//    
//    func refreshStationList(){
//        let urlString = "https://data.rennesmetropole.fr/api/records/1.0/search/?dataset=etat-des-stations-le-velo-star-en-temps-reel&rtows=200&facet=nom&facet=etat&facet=nombreemplacementsactuels&facet=nombreemplacementsdisponibles&facet=nombrevelosdisponibles"
//        guard let url = URL(string: urlString)else{return}
//        
//        URLSession.shared.dataTask(with: url){(data, response, error) in
//            if(error != nil){
//                print(error?.localizedDescription)
//            }
//        
//            guard let data = data else {return}
//
//            do{
//                let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
//                print(json["records"])
//
//                if let records = json["records"] as? NSArray{
//                    print(json["records"])
//                    for station in records {
//                        if let stationDict = station as? NSDictionary {
//                            if let stationFields = stationDict["fields"] as? NSDictionary{
//                                print(stationFields["nom"])
//                                DispatchQueue.main.async {
//                                    self.createStationEntityFrom(dictionary: stationFields)
//                                }
//                            }
//                        }
//                    }
//                }
//            }catch(let error as NSError){
//                    print(error)
//            }
//        }.resume()
//    }
//
//    private func createStationEntityFrom(dictionary:NSDictionary)->NSManagedObject?{
//        let appDelegate = UIApplication.shared.delegate as! AppDelegate
//        let context = appDelegate.persistentContainer.viewContext
//        let entity = NSEntityDescription.entity(forEntityName: "Station", in: context)
//        let newStation = NSManagedObject(entity: entity!, insertInto: context)
//
//        newStation.setValue(dictionary["nom"], forKey: "name")
//        newStation.setValue(String(dictionary["idstation"] as! Int), forKey: "identifier")
//        newStation.setValue(String(dictionary["nombreemplacementsdisponibles"] as! Int), forKey: "nbAvailableSlots")
//        newStation.setValue(String(dictionary["nombrevelosdisponibles"] as! Int), forKey: "nbAvailableBikes")
//        newStation.setValue(dictionary["etat"], forKey: "state")
//        if let tab = dictionary["coordonnees"] as? [Double]{
//            newStation.setValue(tab[0], forKey: "latitude")
//            newStation.setValue(tab[1], forKey: "longitude")
//        }
//        do{
//            try context.save()
//        } catch {
//            print("Saving failed")
//        }
//        return newStation
//    }
//
//    func fetchStations(){
//        let appDelegate = UIApplication.shared.delegate as! AppDelegate
//        
//        let context = appDelegate.persistentContainer.viewContext
//
//        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Station")
//        request.returnsObjectsAsFaults = false
//        do{
//            let stations = try context.fetch(request) as! [Station]
//            stationArray = stations
//
//        }catch{
//            print("CoreDataFetchError")
//            stationArray = nil;
//        }
//    }
//    
//    private func deleteOldStations(){
//        let appDelegate = UIApplication.shared.delegate as! AppDelegate
//
//        let context = appDelegate.persistentContainer.viewContext
//
//        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Station")
//        
//        do{
//            let stations = try context.fetch(request) as! [Station]
//            for station in stations{
//                context.delete(station)
//            }
//            try context.save()
//
//        }catch{
//            print("CoreDataDeleteError")
//            stationArray = nil;
//        }
//    }
//    /*
//    // MARK: - Navigation
//
//    // In a storyboard-based application, you will often want to do a little preparation before navigation
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        // Get the new view controller using segue.destinationViewController.
//        // Pass the selected object to the new view controller.
//    }
//    */
//
//}
