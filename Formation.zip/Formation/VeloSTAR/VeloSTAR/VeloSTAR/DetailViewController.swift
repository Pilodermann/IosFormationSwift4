//
//  DetailViewController.swift
//  VeloSTAR
//
//  Created by neoloc on 24/05/2018.
//  Copyright © 2018 Romain. All rights reserved.
//

import UIKit
import CoreData

class DetailViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var imagePresenter: UIImageView!
    @IBOutlet weak var isfavoriteButton: UIButton!
    @IBOutlet weak var nbAvailableBikes: UILabel!
    @IBOutlet weak var nbAvailableSlots: UILabel!
    @IBOutlet weak var stationNameLabel: UILabel!
    var selectedStation:Station!
    var deleteFavotireView:UILabel!
    
    @IBAction func favoriteButtonClicked(_ sender: Any) {
        selectedStation.favorite = !selectedStation.favorite
        
        if(selectedStation.favorite){
            isfavoriteButton.addSubview(deleteFavotireView)
        } else {
            deleteFavotireView.removeFromSuperview()
        }
        saveStation(station: selectedStation)
    }
    
    @IBAction func selectImageAction(_ sender: Any) {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = true
        present(picker, animated: true)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        var newImage: UIImage?
        if let possibleImage = info["UIImagePickerControllerEditedImage"] as? UIImage {
            newImage = possibleImage
        } else if let possibleImage = info["UIImagePickerControllerOriginalImage"] as? UIImage {
            newImage = possibleImage
        }
        
        imagePresenter.image = newImage
        selectedStation.image = UIImageJPEGRepresentation(newImage!, 1.0) as! NSData
        saveStation(station: selectedStation)
        dismiss(animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        deleteFavotireView = UILabel(frame: CGRect(x: 4, y: 4, width: 56, height: 56))
        deleteFavotireView.textColor = UIColor.red
        deleteFavotireView.adjustsFontSizeToFitWidth = true
        deleteFavotireView.text = "X"
        deleteFavotireView.textAlignment = NSTextAlignment.center
        if(selectedStation.favorite){
            isfavoriteButton.addSubview(deleteFavotireView)
        }
        
        if(selectedStation.image != nil){
            let data : NSData = selectedStation.image!
            let img = UIImage(data: data as Data)
            imagePresenter.image = img
        }
        
        stationNameLabel.text = selectedStation.name
        nbAvailableBikes.text = selectedStation.nbAvailableBikes
        nbAvailableSlots.text = selectedStation.nbAvailableSlots
        isfavoriteButton.isOpaque = !selectedStation.favorite
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    private func saveStation(station : Station){
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        do {
            try context.save()
        } catch {
            print("failed saving")
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
