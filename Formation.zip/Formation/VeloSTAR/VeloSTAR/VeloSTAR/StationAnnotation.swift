//
//  StationMarker.swift
//  VeloSTAR
//
//  Created by neoloc on 24/05/2018.
//  Copyright © 2018 Romain. All rights reserved.
//

import Foundation
import MapKit

class StationAnnotation: NSObject, MKAnnotation{
    
    var coordinate: CLLocationCoordinate2D
    var stationName: String
    var nbOfAvailableBikes: String
    
    init(coordinate:CLLocationCoordinate2D, stationName : String, nbOfAvailableBikes : String){
        self.coordinate = coordinate
        self.stationName = stationName;
        self.nbOfAvailableBikes = nbOfAvailableBikes
    }
    
    public func updateAvailableBikesCount(nbOfAvailableBikes:String){
        self.nbOfAvailableBikes = nbOfAvailableBikes
    }
}
