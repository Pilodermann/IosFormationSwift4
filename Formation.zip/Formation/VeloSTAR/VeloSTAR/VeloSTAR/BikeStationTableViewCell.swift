//
//  BikeStationTableViewCell.swift
//  VeloSTAR
//
//  Created by neoloc on 23/05/2018.
//  Copyright © 2018 Romain. All rights reserved.
//

import UIKit

class BikeStationTableViewCell: UITableViewCell {

    @IBOutlet weak var favoriteIcon: UIImageView!
    @IBOutlet public weak var stationLabel: UILabel!
    @IBOutlet public weak var distanceToStation: UILabel!
    @IBOutlet public weak var availableBikeCount: UILabel!
    @IBOutlet public weak var availableSlotCount: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

    public func setFavoriteIconVisible(isFavorite: Bool){
        favoriteIcon.isHidden = !isFavorite
    }
}
