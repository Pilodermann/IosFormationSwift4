//
//  StationAnnotationView.swift
//  VeloSTAR
//
//  Created by neoloc on 24/05/2018.
//  Copyright © 2018 Romain. All rights reserved.
//

import UIKit
import MapKit

class StationAnnotationView: MKAnnotationView {

    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
}
