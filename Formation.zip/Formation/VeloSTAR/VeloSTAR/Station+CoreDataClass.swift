//
//  Station+CoreDataClass.swift
//  VeloSTAR
//
//  Created by neoloc on 23/05/2018.
//  Copyright © 2018 Romain. All rights reserved.
//
//

import Foundation
import CoreData


public class Station: NSManagedObject {

    public var distanceToStation:Double!
}
