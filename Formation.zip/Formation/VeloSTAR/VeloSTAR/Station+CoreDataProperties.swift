//
//  Station+CoreDataProperties.swift
//  VeloSTAR
//
//  Created by neoloc on 25/05/2018.
//  Copyright © 2018 Romain. All rights reserved.
//
//

import Foundation
import CoreData


extension Station {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Station> {
        return NSFetchRequest<Station>(entityName: "Station")
    }

    @NSManaged public var identifier: String?
    @NSManaged public var latitude: Double
    @NSManaged public var longitude: Double
    @NSManaged public var name: String?
    @NSManaged public var nbAvailableBikes: String?
    @NSManaged public var nbAvailableSlots: String?
    @NSManaged public var state: String?
    @NSManaged public var favorite: Bool
    @NSManaged public var image: NSData?

}
